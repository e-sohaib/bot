import start
import database
import instagram


if __name__ == "__main__":
    print("Done.")