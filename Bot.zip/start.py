import telebot
import os
import time
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import logging
from database import User
from datetime import datetime
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from instagram import download_instagram_content ,detect_content_type , is_valid_instagram_link
import lzma
import json


BOT_TOKEN = "7156255717:AAHBxvvhrRqNED5ZBiO9ZOb3ZRAfu0QmQik"
MYSQL = "mysql+pymysql://root:root@localhost:3306/abzar_database"
ADMIN_ID = '6040165079'
curent_dir = os.getcwd()
engine = create_engine(MYSQL, echo=True)
Session = sessionmaker(bind=engine)
# Telegram Bot setup
bot = telebot.TeleBot(BOT_TOKEN)
logging.basicConfig(filename='Radepa.log', level=logging.INFO, format='%(asctime)s - %(message)s')
#menu reply
def create_main_menu_reply(tg_id):
    if tg_id == ADMIN_ID:
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add(KeyboardButton("Instagram"))
        markup.add(KeyboardButton("Youtube"))
        markup.add(KeyboardButton("Linkedin"))
        markup.add(KeyboardButton("Divar"))
    else:
        markup.add(KeyboardButton("Instagram"))
        
    return markup
#start
@bot.callback_query_handler(func=lambda call:call.data == 'khonsa')
def khonsa(call):
    pass
@bot.message_handler(commands=['start','help'])
def start_handling(message):
    user_tgid = message.from_user.id
    session = Session()
    Uzer = session.query(User).filter_by(telegram_id = str(user_tgid)).first()
    print(Uzer)
    if Uzer == None:
        new_user = User(telegram_id = user_tgid ,
                        date_joined = datetime.now(),
                        )
        session.add(new_user)
        session.commit()
        bot.send_message(user_tgid , "Welcom!" , reply_markup = create_main_menu_reply(user_tgid))   
    else:
        bot.send_message(user_tgid , "Welcom Back!" , reply_markup = create_main_menu_reply(user_tgid))
#uplaod customizig
def ig_caption(tg_id):
    with open(f"{curent_dir}\\instadownloads-{tg_id}\\{tg_id}.txt" , 'r' , encoding = 'utf-8') as cap:
        caption = cap.read()
    return caption
#extract .json.xs to json
def ig_json_dump(tg_id):
    path = f'{curent_dir}\\instadownloads-{tg_id}\\{tg_id}.json.xz'
    output_file = f'{curent_dir}\\instadownloads-{tg_id}\\{tg_id}.json'
    with lzma.open(path, "rb") as compressed_file:
        raw_data = compressed_file.read().decode("utf-8")
        json_data = json.loads(raw_data)
    with open(output_file, "w") as extracted_file:
        json.dump(json_data, extracted_file, indent=4)
#read json and prepare markup        
def ig_reply_markup(tg_id):
    ig_json_dump(tg_id)
    with open(f"{curent_dir}\\instadownloads-{tg_id}\\{tg_id}.json ", 'r' ,encoding='utf-8') as m:
        dic = json.load(m)
        
    likes_count = dic['node']["edge_media_preview_like"]['count']
    comments_count = dic['node']["edge_media_preview_comment"]['count']
    if dic['node']["__typename"] == "GraphImage":
        view_count = ''
    else:
        view_count = dic['node']["video_view_count"]
    likes=InlineKeyboardButton(f"Likes ❤️ {likes_count}", callback_data="khonsa")
    comments = InlineKeyboardButton(f"Comments 💬 {comments_count}", callback_data="khonsa")
    views = InlineKeyboardButton(f"Views 👁‍🗨 {view_count}", callback_data="khonsa")
    markup = InlineKeyboardMarkup([
    [likes, comments],
    [views],])
    return markup
#load comments
def ig_coments(tg_id):
    with open(f"{curent_dir}\\instadownloads-{tg_id}\\{tg_id}.json ", 'r' ,encoding='utf-8') as m:
            dic = json.load(m)
    listofcomments =[]
    A = dic['node']
    B = dic['instaloader']
    ALL_COMMENTS = A['edge_media_to_parent_comment']['edges']
    for item in ALL_COMMENTS:
        listofcomments.append(item['node']['text'])
    return listofcomments        
#instadownloader
def download_ig(message , session):
    t0 = time.time()
    user = session.query(User).filter_by(telegram_id = message.from_user.id ).first()
    if user.daily_requests == user.max_requests:
        bot.send_message(user.telegram_id , f"You reached limit")   
        return
    elif user.daily_requests < user.max_requests:
        link = message.text
        tg_id = user.telegram_id
        CNTNT_type = detect_content_type(link)
        bot.send_message(user.telegram_id , "Wait a moment ...")
        result = download_instagram_content(link , str(tg_id))
        if result == "Incorrect Link.":
            bot.reply_to(message , result)
            return
        elif result == "The type of link entered is not recognized.":
            bot.reply_to(message , result)
            return
        elif result == "Download story is login required.":
            bot.reply_to(message , result)
            return
        elif result == "File format not suported.":
            bot.reply_to(message , result)
            return  
        else:
            bot.send_message(tg_id , 'Youre File Is Downloading') 
            bot.reply_to(message , result)     
            user.daily_requests = user.daily_requests + 1
            session.commit()
            #upload too telegram
            bot.send_message(tg_id , 'uploading to telegram')
            if CNTNT_type == "post":
                all_in_dir = os.listdir(f"{curent_dir}\\instadownloads-{tg_id}\\")
                lisofposst = [item  for item in all_in_dir if item.split('.')[1] == "jpg"]
                for jpg in lisofposst:
                    with open(f"{curent_dir}\\instadownloads-{tg_id}\\{jpg}" ,'rb') as f:
                        bot.send_photo(tg_id , f ,caption=ig_caption(tg_id),reply_markup=ig_reply_markup(tg_id))  
            elif CNTNT_type == "reel":
                with open(f"{curent_dir}\\instadownloads-{tg_id}\\{tg_id}.mp4" ,'rb') as f:
                    bot.send_photo(tg_id , f ,caption=ig_caption(tg_id),reply_markup=ig_reply_markup(tg_id))  
                
            comments = 'Some comments:\n'
            i = 1  
            for item in ig_coments(tg_id):
                comments = ''.join(f"{comments}{i} - {item}\n")
                i+=1
            bot.send_message(user.telegram_id , comments)    
            bot.send_message(user.telegram_id , f'remaing requests {user.max_requests - user.daily_requests}')
            t1 = time.time()
            bot.send_message(ADMIN_ID , f'time elapsed: {t1 - t0}')
            clear_user_files(tg_id)
            return
#clear directory of user
def clear_user_files(tg_id):
    files = os.listdir(f"{curent_dir}\\instadownloads-{tg_id}")
    for file in files:
        os.remove(f"{curent_dir}\\instadownloads-{tg_id}\\{file}")
#handle Instagram message       
@bot.message_handler(func=lambda message:message.text == "Instagram")
def start_handling(message):
    session = Session()
    mess =bot.reply_to(message, "send an instagram valid link")
    bot.register_next_step_handler(mess, download_ig ,session)
#handle Youtube message       
@bot.message_handler(func=lambda message:message.text == "Youtube")
def start_handling(message):
    pass














def main():
    try:
        bot.polling(non_stop=True , timeout= 50)
    except Exception as main:
        logging.error(f"bot start nashod : \n {main}")
if  __name__ == "__main__":
    
    main()


